"""把 Python 语法/写法诊断接入应用「预览面板」（Copilot 插件 py-lint-tips 的服务）。

用户真正编辑代码的地方是预览面板（CodePreviewWindow）里的代码编辑器。本服务在
运行时扫描预览面板实例（含主题切换后新建的实例），给它的编辑器挂上：

  · 输入停顿后的一次只读语法解析（ast，不运行代码）；
  · 语法错误：整行浅红底 + 红色波浪线；
  · 写法提示：整行浅琥珀底 + 琥珀色波浪线；
  · 悬停代码行时的详解小面板。

不改应用源码、不写文件、不联网；停用插件时本服务立即卸载并清掉所有标记。
"""

import time

from PyQt6.QtCore import QEvent, QObject, QPoint, Qt, QTimer
from PyQt6.QtGui import QColor, QTextCursor
from PyQt6.QtWidgets import QApplication, QPlainTextEdit

try:
    from ..pages.py_lint_page import (
        PyLintPage, _ERR, _MAX_CHECK_CHARS, _TipPanel, _WARN,
        analyze_code, build_line_tip,
    )
except Exception:      # 包结构异常时安静降级：插件其余部分仍可正常工作
    PyLintPage = None
    _ERR = "#C96A5E"
    _WARN = "#C6A15B"
    _MAX_CHECK_CHARS = 300_000
    _TipPanel = None
    analyze_code = None
    build_line_tip = None

_STATE = {"timer": None, "items": [], "tip": None}

#: 单次最多标注多少个提示行（与插件页一致，防超大文件绘制卡顿）
_MAX_DIAG_LINES = 200
#: 输入停顿多久后重新解析（毫秒）
_CHECK_DELAY_MS = 380
#: 鼠标在同一行稳定停留多久才弹详解面板（毫秒）：太短会在快速划过时反复闪
_HOVER_DELAY_MS = 320
#: 预览面板/新建实例的扫描间隔（毫秒）
_SCAN_INTERVAL_MS = 1500


def _preview_class():
    """应用里的预览面板类（应用模块尚未导入时返回 None）。"""
    try:
        from zhuzhu_Copilot.ui import agent_panel as ap
        return getattr(ap, "CodePreviewWindow", None)
    except Exception:
        return None


def _tip_panel():
    """全局共用的悬停小面板（懒创建；服务停止时关闭）。"""
    if _TipPanel is None:
        return None
    if _STATE.get("tip") is None:
        try:
            _STATE["tip"] = _TipPanel()
        except Exception:
            return None
    return _STATE.get("tip")


class _PreviewLint(QObject):
    """一个预览编辑器的诊断挂载（编辑器销毁时自动卸载）。

    继承 QObject 是硬性要求：Qt 的 `installEventFilter` 只接受 QObject，
    普通 Python 对象会被拒绝（悬停事件永远收不到）。
    """

    def __init__(self, win, editor):
        super().__init__()
        self.win = win
        self.editor = editor
        self._analysis = None
        self._analysis_version = -1
        self._text_version = 0
        self._hover_line = -1
        self._hover_pos = None       # 最近一次鼠标移动在视口内的坐标

        self._check_timer = QTimer()
        self._check_timer.setSingleShot(True)
        self._check_timer.setInterval(_CHECK_DELAY_MS)
        self._check_timer.timeout.connect(self._check)

        self._hover_timer = QTimer()
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(_HOVER_DELAY_MS)
        self._hover_timer.timeout.connect(self._show_tip)

        editor.textChanged.connect(self._on_changed)
        editor.destroyed.connect(self._on_destroyed)
        # 悬停事件需要视口开启鼠标跟踪；离开编辑器时恢复原来的设置
        self._prev_tracking = None
        try:
            vp = editor.viewport()
            self._prev_tracking = vp.hasMouseTracking()
            vp.setMouseTracking(True)
            vp.installEventFilter(self)
        except Exception:
            self._prev_tracking = None
        self._on_changed()

    # ---------- 状态 ----------
    def alive(self) -> bool:
        try:
            if self.editor is None or self.win is None:
                return False
            self.editor.isVisible()
            self.win.isVisible()
            return True
        except Exception:
            return False

    def _is_python(self) -> bool:
        """只诊断真正的 .py 文件；差异视图 / 非代码预览不标注。"""
        try:
            if float(getattr(self.win, "_diff_until", 0) or 0) > time.time():
                return False
            path = str(getattr(self.win, "_edit_path", "") or "").lower()
            return path.endswith((".py", ".pyw", ".pyi"))
        except Exception:
            return False

    # ---------- 检查 ----------
    def _on_changed(self):
        self._text_version += 1
        self._hide_tip()
        self._check_timer.start()

    def _check(self):
        if self.editor is None or analyze_code is None:
            return
        if not self._is_python():
            self._analysis = None
            self._analysis_version = self._text_version
            self._clear_marks()
            return
        try:
            text = self.editor.toPlainText()
        except Exception:
            return
        if len(text) > _MAX_CHECK_CHARS:
            self._analysis = None
            self._analysis_version = self._text_version
            self._clear_marks()
            return
        try:
            self._analysis = analyze_code(text)
        except Exception:
            self._analysis = None
            self._analysis_version = self._text_version
            self._clear_marks()
            return
        self._analysis_version = self._text_version
        self._paint_marks()

    def _clear_marks(self):
        try:
            self.editor.setExtraSelections([])
        except Exception:
            pass

    def _paint_marks(self):
        """语法错误与写法提示直接画在预览编辑器里（整行底色 + 波浪线）。"""
        if self.editor is None or PyLintPage is None:
            return
        info = self._analysis or {}
        doc = self.editor.document()
        selections = []
        levels = {}

        err = info.get("error")
        err_line = 0
        if err and int(err.get("line") or 0) > 0:
            err_line = min(max(1, int(err["line"])), max(1, doc.blockCount()))
            levels[err_line] = "error"

        issues = {int(k): v for k, v in (info.get("issues") or {}).items()}
        warn_lines = [ln for ln in sorted(issues)
                      if 1 <= ln <= doc.blockCount() and ln != err_line]
        warn_lines = warn_lines[:_MAX_DIAG_LINES]

        if err_line:
            col = max(0, int(err.get("col") or 0) - 1)
            PyLintPage._add_diag(selections, doc.findBlockByNumber(err_line - 1),
                                 QColor(201, 106, 94, 34), QColor(_ERR), col)
        for ln in warn_lines:
            PyLintPage._add_diag(selections, doc.findBlockByNumber(ln - 1),
                                 QColor(198, 161, 91, 24),
                                 QColor(208, 167, 93, 230), None)
        try:
            self.editor.setExtraSelections(selections)
        except Exception:
            pass

    # ---------- 悬停小面板 ----------
    def eventFilter(self, obj, event):      # noqa: N802  Qt 命名
        if self.editor is None:
            return False
        et = event.type()
        if et == QEvent.Type.MouseMove:
            if QApplication.mouseButtons() & Qt.MouseButton.LeftButton:
                self._hide_tip()
                return False
            self._hover_pos = event.pos()
            try:
                line = self.editor.cursorForPosition(event.pos()).blockNumber() + 1
            except Exception:
                return False
            if line == self._hover_line:
                tip = _STATE.get("tip")
                if (tip is None or not tip.isVisible()):
                    if not self._hover_timer.isActive():
                        self._hover_timer.start()
                return False
            # 划过其他行时只重置计时，不隐藏已有面板 → 不闪
            self._hover_line = line
            self._hover_timer.start()
        elif et in (QEvent.Type.Leave, QEvent.Type.Wheel, QEvent.Type.FocusOut):
            self._hide_tip()
        return False

    def _show_tip(self):
        if self.editor is None or build_line_tip is None:
            return
        line = self._hover_line
        if line < 1 or self._hover_pos is None:
            return
        # 稳定停留校验：计时器到点时鼠标必须仍在同一行（划过时只重置计时）
        try:
            line_now = self.editor.cursorForPosition(self._hover_pos).blockNumber() + 1
        except Exception:
            return
        if line_now != line:
            self._hover_line = line_now
            self._hover_timer.start()
            return
        try:
            block = self.editor.document().findBlockByNumber(line - 1)
        except Exception:
            return
        if not block.isValid():
            return
        src = block.text()
        info = (self._analysis
                if self._analysis_version == self._text_version else None)
        try:
            html = build_line_tip(line, src, info)
        except Exception:
            return
        if not html:
            self._hide_tip()
            return
        tip = _tip_panel()
        if tip is None:
            return
        try:
            rect = self.editor.cursorRect(QTextCursor(block))
            pos = self.editor.viewport().mapToGlobal(rect.topLeft())
            tip.show_tip(html, QPoint(pos.x() + 34, pos.y() + 14))
        except Exception:
            pass

    def _hide_tip(self, reset_line: bool = True):
        try:
            if self._hover_timer.isActive():
                self._hover_timer.stop()
        except Exception:
            pass
        tip = _STATE.get("tip")
        if tip is not None:
            try:
                tip.hide_tip()
            except Exception:
                pass
        if reset_line:
            self._hover_line = -1
            self._hover_pos = None

    # ---------- 卸载 ----------
    def detach(self):
        try:
            self._check_timer.stop()
        except Exception:
            pass
        try:
            self._hover_timer.stop()
        except Exception:
            pass
        self._hide_tip()
        self._clear_marks()
        # 断开信号连接：编辑器仍存活时（插件停用）不能让它继续持有本对象
        if self.editor is not None:
            for sig, fn in ((self.editor.textChanged, self._on_changed),
                            (self.editor.destroyed, self._on_destroyed)):
                try:
                    sig.disconnect(fn)
                except Exception:
                    pass
        try:
            vp = self.editor.viewport()
            vp.removeEventFilter(self)
            if self._prev_tracking is not None:
                vp.setMouseTracking(bool(self._prev_tracking))
        except Exception:
            pass
        self.editor = None
        self.win = None
        try:
            _STATE["items"].remove(self)
        except ValueError:
            pass

    def _on_destroyed(self, *_args):
        self.detach()


def _scan():
    """扫描预览面板实例并把诊断挂到它的编辑器上（新实例/重建实例自动覆盖）。"""
    app = QApplication.instance()
    if app is None:
        return
    cls = _preview_class()
    if cls is None:
        return
    _STATE["items"] = [it for it in _STATE["items"] if it.alive()]
    for w in app.allWidgets():
        try:
            if not isinstance(w, cls):
                continue
            editor = getattr(w, "text", None)
            if not isinstance(editor, QPlainTextEdit):
                continue
            if any(it.editor is editor for it in _STATE["items"]):
                continue
            _STATE["items"].append(_PreviewLint(w, editor))
        except Exception:
            continue


def start():
    """服务入口（GUI 线程调用）：立即扫描一次，之后定期发现新预览面板。"""
    if QApplication.instance() is None or _TipPanel is None:
        return None
    _scan()
    if _STATE.get("timer") is None:
        timer = QTimer()
        timer.setInterval(_SCAN_INTERVAL_MS)
        timer.timeout.connect(_scan)
        timer.start()
        _STATE["timer"] = timer
    return None


def stop():
    """服务停止：卸载全部诊断挂载并关闭悬停面板。"""
    timer = _STATE.pop("timer", None)
    if timer is not None:
        try:
            timer.stop()
            timer.deleteLater()
        except Exception:
            pass
    for item in list(_STATE.get("items") or []):
        try:
            item.detach()
        except Exception:
            pass
    _STATE["items"] = []
    tip = _STATE.pop("tip", None)
    if tip is not None:
        try:
            tip.close()
        except Exception:
            pass
