"""Python 语法高亮 + 逐行提示面板（Copilot 插件 py-lint-tips 的页面模块）。

页面职责：
  · 编辑器实时做 Python 词法着色，输入停顿后自动做一次只读语法解析；
  · 语法错误的行在编辑器里标红（整行底色 + 波浪下划线）；
  · 鼠标悬停某一行代码时，在该行旁弹出小面板：这一行做什么、缩进层级、
    该行的语法错误与本行写法提示。

全部分析都在本机完成：不联网、不运行用户代码，源码不离开本机。
"""

import ast
import builtins
import io
import keyword
import re
import tokenize

from PyQt6.QtCore import QPoint, QRect, QRectF, QSize, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QColor, QFont, QFontMetricsF, QPainter, QPainterPath,
                         QSyntaxHighlighter, QTextCharFormat, QTextCursor,
                         QTextFormat)
from PyQt6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout,
                             QLabel, QPlainTextEdit, QPushButton, QTextEdit,
                             QVBoxLayout, QWidget)

# ---------------------------------------------------------------------------
# 配色（纯黑底 + 淡灰 + 白 + 深蓝；不使用 emoji 与彩色图标）
# ---------------------------------------------------------------------------
_BG = "#080B10"
_EDIT_BG = "#0A0E14"
_SURFACE = "#0D131B"
_BORDER = "#242F3E"
_TEXT = "#D6DEE7"
_DIM = "#8794A3"
_ACCENT = "#3E6ED0"
_OK = "#6FA58C"
_WARN = "#C6A15B"
_ERR = "#C96A5E"

_SYN_KW = "#6C93E8"
_SYN_CONST = "#B8C4D2"
_SYN_STR = "#7FA99A"
_SYN_CMT = "#5F6B79"
_SYN_NUM = "#C0A46A"
_SYN_BUILTIN = "#93A9BF"
_SYN_SELF = "#A9B6C6"
_SYN_NAME = "#EDF1F5"
_SYN_DECO = "#9AA7B8"

#: 单行超过该长度给出提示（现代 Python 常见的 99 列约定）
_MAX_LINE = 99
#: 超过该字符数的文本暂停实时分析，保证编辑不卡顿
_MAX_CHECK_CHARS = 300_000
#: 鼠标在同一行稳定停留多久才弹提示（毫秒）：太短会在快速划过时反复闪
_HOVER_DELAY_MS = 320

_STRING_PREFIXES = frozenset((
    "r", "u", "b", "f", "br", "rb", "fr", "rf",
))
_KEYWORDS = frozenset(keyword.kwlist) | frozenset(("match", "case", "_"))
_CONSTS = frozenset(("True", "False", "None", "NotImplemented", "Ellipsis"))
_BUILTIN_NAMES = frozenset(dir(builtins)) - frozenset(("__import__",))

_NUM_RE = re.compile(
    r"0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+"
    r"|\d[\d_]*(?:\.\d*)?(?:[eE][+-]?\d+)?[jJ]?")

_NONE_CMP_RE = re.compile(r"(?:==|!=)\s*None\b")
_BARE_EXCEPT_RE = re.compile(r"^\s*except\s*:\s*$")
_BROAD_EXCEPT_RE = re.compile(r"^\s*except\s+(?:Exception|BaseException)\s*:")
_BOOL_CMP_RE = re.compile(r"(?:==|!=)\s*(?:True|False)\b")
_IS_LITERAL_RE = re.compile(r"\bis\s+(?:[0-9]|\"|')")
_MUTABLE_DEFAULT_RE = re.compile(r"\bdef\s+\w+\s*\([^)]*=\s*[\[{]")


def _esc(text) -> str:
    """HTML 转义（提示面板是富文本标签）。"""
    s = str(text or "")
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ---------------------------------------------------------------------------
# 词法着色
# ---------------------------------------------------------------------------
def _fmt(color: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if bold:
        f.setFontWeight(int(QFont.Weight.DemiBold))
    if italic:
        f.setFontItalic(True)
    return f


class PythonHighlighter(QSyntaxHighlighter):
    """逐行扫描的 Python 词法高亮（支持三引号跨行状态）。"""

    def __init__(self, document):
        super().__init__(document)
        self._kw = _fmt(_SYN_KW, bold=True)
        self._const = _fmt(_SYN_CONST)
        self._str = _fmt(_SYN_STR)
        self._cmt = _fmt(_SYN_CMT, italic=True)
        self._num = _fmt(_SYN_NUM)
        self._builtin = _fmt(_SYN_BUILTIN)
        self._self = _fmt(_SYN_SELF, italic=True)
        self._name = _fmt(_SYN_NAME, bold=True)
        self._deco = _fmt(_SYN_DECO)

    def highlightBlock(self, text: str):      # noqa: N802  Qt 命名
        n = len(text)
        state = self.previousBlockState()
        i = 0
        # 1) 续上一行的三引号字符串
        if state in (1, 2):
            q = "'''" if state == 1 else '"""'
            end = text.find(q)
            if end < 0:
                self.setFormat(0, n, self._str)
                self.setCurrentBlockState(state)
                return
            self.setFormat(0, end + 3, self._str)
            i = end + 3
        self.setCurrentBlockState(0)

        # 2) 行首装饰器
        stripped = text.lstrip()
        if stripped.startswith("@"):
            start = n - len(stripped)
            m = re.match(r"@[A-Za-z_][\w.]*", stripped)
            if m:
                self.setFormat(start, m.end(), self._deco)

        # 3) 逐字符扫描
        next_is_name = False
        while i < n:
            ch = text[i]
            if ch == "#":
                self.setFormat(i, n - i, self._cmt)
                break
            if ch in ("'", '"'):
                triple = ch * 3
                if text.startswith(triple, i):
                    end = text.find(triple, i + 3)
                    if end < 0:
                        self.setFormat(i, n - i, self._str)
                        self.setCurrentBlockState(1 if ch == "'" else 2)
                        break
                    self.setFormat(i, end + 3 - i, self._str)
                    i = end + 3
                    continue
                j = i + 1
                while j < n:
                    if text[j] == "\\":
                        j += 2
                        continue
                    if text[j] == ch:
                        j += 1
                        break
                    j += 1
                j = min(j, n)
                self.setFormat(i, j - i, self._str)
                i = j
                continue
            if ch.isalpha() or ch == "_":
                j = i + 1
                while j < n and (text[j].isalnum() or text[j] == "_"):
                    j += 1
                word = text[i:j]
                low = word.lower()
                if low in _STRING_PREFIXES and j < n and text[j] in ("'", '"'):
                    self.setFormat(i, j - i, self._str)   # 字符串前缀
                elif word in ("def", "class"):
                    self.setFormat(i, j - i, self._kw)
                    next_is_name = True
                elif next_is_name:
                    self.setFormat(i, j - i, self._name)
                    next_is_name = False
                elif word in _KEYWORDS:
                    self.setFormat(i, j - i, self._kw)
                elif word in _CONSTS:
                    self.setFormat(i, j - i, self._const)
                elif word in ("self", "cls"):
                    self.setFormat(i, j - i, self._self)
                elif word in _BUILTIN_NAMES:
                    self.setFormat(i, j - i, self._builtin)
                i = j
                continue
            if ch.isdigit():
                m = _NUM_RE.match(text, i)
                if m:
                    self.setFormat(i, m.end() - i, self._num)
                    i = m.end()
                else:
                    i += 1
                continue
            i += 1


# ---------------------------------------------------------------------------
# 静态检查（只读解析，绝不执行）
# ---------------------------------------------------------------------------
def _literal_spans(text: str) -> dict:
    """扫描字符串/注释 token 的列区间：{1 起行号: [(起列, 止列)]}。

    行级规则（== None、is、except Exception 等）只在**代码区域**生效：
    注释与字符串里出现的同样文字不应被误报为写法问题。
    代码有语法错误时 tokenize 可能中途失败 —— 保留已扫描到的区间即可。
    """
    spans = {}
    try:
        gen = tokenize.generate_tokens(io.StringIO(str(text or "")).readline)
    except Exception:
        return spans
    try:
        for tok in gen:
            if tok.type not in (tokenize.STRING, tokenize.COMMENT):
                continue
            (srow, scol), (erow, ecol) = tok.start, tok.end
            if erow == srow:
                spans.setdefault(srow, []).append((scol, ecol))
                continue
            # 多行字符串：起始行从引号到行尾、中间行整行、结束行从行首到收尾引号
            spans.setdefault(srow, []).append((scol, 10**9))
            for row in range(srow + 1, erow):
                spans.setdefault(row, []).append((0, 10**9))
            spans.setdefault(erow, []).append((0, ecol))
    except Exception:
        pass
    return spans


def _code_hit(rx, line: str, spans) -> bool:
    """规则在「非字符串/非注释」区域是否命中（同一规则每行只报一次）。"""
    for m in rx.finditer(line):
        if not any(a <= m.start() < b for a, b in (spans or ())):
            return True
    return False


def lint_line(line: str, spans=None) -> list:
    """单行写法提示：返回 [(级别, 文本)]。spans 见 `_literal_spans`。"""
    out = []
    if not line.strip():
        return out
    lead = line[:len(line) - len(line.lstrip())]
    if "\t" in lead:
        out.append(("warn", "缩进混用制表符与空格，建议统一为 4 空格"
                    if " " in lead else "使用制表符缩进，建议统一为 4 空格"))
    if line != line.rstrip():
        out.append(("warn", "行尾有多余空白"))
    if len(line) > _MAX_LINE:
        out.append(("warn", "该行长度 %d 字符，超过 %d 列" % (len(line), _MAX_LINE)))
    if _code_hit(_NONE_CMP_RE, line, spans):
        out.append(("warn", "与 None 比较建议使用 is / is not"))
    if _code_hit(_BARE_EXCEPT_RE, line, spans):
        out.append(("warn", "裸 except 会吞掉全部异常，建议写明异常类型"))
    if _code_hit(_BROAD_EXCEPT_RE, line, spans):
        out.append(("warn", "捕获 Exception 过于宽泛，建议只捕获需要的异常类型"))
    if _code_hit(_BOOL_CMP_RE, line, spans):
        out.append(("warn", "与 True / False 比较可直接使用布尔表达式"))
    if _code_hit(_IS_LITERAL_RE, line, spans):
        out.append(("warn", "is 只用于 None / True / False 等单例，与字面量比较应使用 =="))
    if _code_hit(_MUTABLE_DEFAULT_RE, line, spans):
        out.append(("warn", "可变对象作为默认参数，多次调用会共享同一份对象"))
    return out


def _lint_all(text: str) -> dict:
    issues = {}
    spans = _literal_spans(text)
    for i, line in enumerate(text.splitlines(), 1):
        rows = lint_line(line, spans.get(i))
        if rows:
            issues[i] = rows
    return issues


def _expr(node, limit: int = 46) -> str:
    """把 AST 子节点还原成单行文本（截断，失败时返回空串）。"""
    try:
        s = ast.unparse(node)
    except Exception:
        return ""
    s = " ".join(str(s).split())
    if len(s) > limit:
        s = s[:limit - 1] + "…"
    return s


_FUNC_KINDS = (ast.FunctionDef, ast.AsyncFunctionDef)


def _describe_node(node) -> tuple:
    """AST 节点 → (行类型, 人类可读说明)。"""
    if isinstance(node, _FUNC_KINDS):
        a = node.args
        args = [x.arg for x in a.posonlyargs + a.args]
        if a.vararg:
            args.append("*" + a.vararg.arg)
        args += [x.arg for x in a.kwonlyargs]
        if a.kwarg:
            args.append("**" + a.kwarg.arg)
        word = "异步函数" if isinstance(node, ast.AsyncFunctionDef) else "函数"
        desc = "定义%s %s（参数：%s）" % (
            word, node.name, "、".join(args) if args else "无")
        if node.decorator_list:
            desc += "，带 %d 个装饰器" % len(node.decorator_list)
        if node.returns is not None:
            desc += "，返回标注 %s" % _expr(node.returns, 24)
        return "函数定义", desc
    if isinstance(node, ast.ClassDef):
        bases = "、".join(_expr(b, 24) for b in node.bases) or "无"
        return "类定义", "定义类 %s（基类：%s）" % (node.name, bases)
    if isinstance(node, ast.Import):
        return "导入", "导入模块 " + "、".join(a.name for a in node.names)
    if isinstance(node, ast.ImportFrom):
        return "导入", "从 %s 导入 %s" % (
            node.module or "相对路径", "、".join(a.name for a in node.names))
    if isinstance(node, ast.Assign):
        targets = "、".join(_expr(t, 24) for t in node.targets)
        return "赋值", "把 %s 赋给 %s" % (_expr(node.value, 30) or "表达式", targets)
    if isinstance(node, ast.AnnAssign):
        return "赋值", "声明 %s，类型标注 %s，值为 %s" % (
            _expr(node.target, 20), _expr(node.annotation, 20),
            _expr(node.value, 20) if node.value is not None else "空")
    if isinstance(node, ast.AugAssign):
        return "赋值", "%s 进行 %s 运算" % (
            _expr(node.target, 20), type(node.op).__name__.replace("Op", ""))
    if isinstance(node, ast.Return):
        if node.value is None:
            return "返回", "结束当前函数（无返回值）"
        return "返回", "返回 " + (_expr(node.value, 42) or "表达式")
    if isinstance(node, ast.Call):
        n = len(node.args) + len(node.keywords)
        return "调用", "调用 %s，传入 %d 个参数" % (_expr(node.func, 34), n)
    if isinstance(node, ast.If):
        return "条件分支", "条件判断：%s" % (_expr(node.test, 42) or "表达式")
    if isinstance(node, ast.While):
        return "循环", "while 循环，条件：%s" % (_expr(node.test, 42) or "表达式")
    if isinstance(node, (ast.For, ast.AsyncFor)):
        word = "异步 for" if isinstance(node, ast.AsyncFor) else "for"
        return "循环", "%s 循环：遍历 %s，每项赋给 %s" % (
            word, _expr(node.iter, 30), _expr(node.target, 20))
    if isinstance(node, ast.Try):
        return "异常处理", "try 异常处理块（%d 个 except 分支）" % len(node.handlers)
    if isinstance(node, ast.ExceptHandler):
        exc = "全部异常" if node.type is None else (_expr(node.type, 28) or "异常")
        return "异常处理", "捕获异常 %s 并处理" % exc
    if isinstance(node, (ast.With, ast.AsyncWith)):
        items = "、".join(_expr(it.context_expr, 26) for it in node.items)
        return "上下文管理", "进入上下文：%s" % items
    if isinstance(node, ast.Raise):
        return "抛出异常", "抛出 %s" % (_expr(node.exc, 34) if node.exc else "当前异常")
    if isinstance(node, ast.Assert):
        return "断言", "断言条件：%s" % (_expr(node.test, 42) or "表达式")
    if isinstance(node, ast.Pass):
        return "占位", "pass：占位语句，稍后再补实现"
    if isinstance(node, ast.Break):
        return "控制", "break：跳出当前循环"
    if isinstance(node, ast.Continue):
        return "控制", "continue：跳过本次循环剩余部分"
    if isinstance(node, ast.Global):
        return "声明", "声明全局变量 " + "、".join(node.names)
    if isinstance(node, ast.Nonlocal):
        return "声明", "声明外层变量 " + "、".join(node.names)
    if isinstance(node, ast.Delete):
        return "删除", "删除 " + "、".join(_expr(t, 20) for t in node.targets)
    if isinstance(node, ast.Lambda):
        return "匿名函数", "定义匿名函数 lambda"
    if isinstance(node, (ast.Yield, ast.YieldFrom)):
        return "生成器", "产出值 " + (_expr(node.value, 34) if node.value is not None else "")
    if isinstance(node, ast.Await):
        return "异步", "等待异步任务 " + (_expr(node.value, 34) or "")
    if isinstance(node, ast.Match):
        return "模式匹配", "按模式匹配 %s" % (_expr(node.subject, 40) or "表达式")
    if isinstance(node, ast.Expr):
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            return "字符串", "字符串表达式（通常是文档字符串或说明文本）"
        return "表达式", _expr(node.value, 44) or "表达式"
    return "", ""


def _fallback_line(src: str) -> tuple:
    """无法解析时按行首关键字判断行类型。"""
    s = src.strip()
    if s.startswith("#"):
        return "注释", "注释行，不参与执行。"
    if re.match(r"^(async\s+def|def)\s+", s):
        return "函数定义", "定义函数"
    if re.match(r"^class\s+", s):
        return "类定义", "定义类"
    if re.match(r"^(import|from)\s+", s):
        return "导入", "导入模块"
    if re.match(r"^(if|elif)\s+", s):
        return "条件分支", "条件判断"
    if s.startswith("else"):
        return "条件分支", "else 分支：上面条件都不成立时执行"
    if re.match(r"^(for|while)\s+", s):
        return "循环", "循环结构"
    if re.match(r"^(try|except|finally)\s*", s):
        return "异常处理", "异常处理分支"
    if re.match(r"^with\s+", s):
        return "上下文管理", "with 上下文块"
    if s.startswith("return"):
        return "返回", "返回结果"
    if re.match(r"^(assert|raise)\s+", s):
        return "抛出异常", "断言或抛错"
    if s.startswith("@"):
        return "装饰器", "装饰器：对下面的函数/类做包装"
    if "=" in s:
        return "赋值", "赋值语句"
    if "(" in s:
        return "调用", "函数或对象调用"
    return "语句", ""


_RANK = {
    "FunctionDef": 0, "AsyncFunctionDef": 0, "ClassDef": 1,
    "Import": 2, "ImportFrom": 2,
    "Assign": 3, "AnnAssign": 3, "AugAssign": 3,
    "Return": 4, "Raise": 5, "Assert": 5,
    "If": 6, "For": 7, "AsyncFor": 7, "While": 7,
    "Try": 8, "ExceptHandler": 8, "With": 9, "AsyncWith": 9,
    "Call": 10, "Expr": 11,
}


def _best_node(nodes) -> object:
    """同一行有多个节点时取「最具代表性」的那个（定义 > 赋值 > 调用）。"""
    return min(nodes, key=lambda o: (_RANK.get(type(o).__name__, 12),
                                     getattr(o, "col_offset", 0), getattr(o, "end_col_offset", 0)))


def analyze_code(text: str) -> dict:
    """对全文做一次只读解析，返回语法错误、按行节点与逐行提示。"""
    text = str(text or "")
    err = None
    tree = None
    nodes_by_line = {}
    if text.strip():
        try:
            tree = ast.parse(text)
        except SyntaxError as e:
            err = {"line": int(e.lineno or 0), "col": int(e.offset or 0),
                   "message": str(e.msg or e)}
        except (ValueError, MemoryError, RecursionError) as e:
            err = {"line": 0, "col": 0, "message": str(e)}
    if tree is not None:
        try:
            for node in ast.walk(tree):
                ln = getattr(node, "lineno", None)
                if ln:
                    nodes_by_line.setdefault(int(ln), []).append(node)
        except Exception:
            nodes_by_line = {}
    return {"text": text, "tree": tree, "error": err,
            "nodes_by_line": nodes_by_line, "issues": _lint_all(text)}


def build_line_tip(line_no: int, src: str, info=None) -> str:
    """生成某一行的小面板 HTML；空行返回空串（不弹面板）。"""
    if not str(src or "").strip():
        return ""
    info = info or {}
    kind, desc = "", ""
    nodes = (info.get("nodes_by_line") or {}).get(line_no) or []
    if nodes:
        try:
            kind, desc = _describe_node(_best_node(nodes))
        except Exception:
            kind, desc = "", ""
    if not desc:
        kind, desc = _fallback_line(src)

    if info:
        issue_rows = list((info.get("issues") or {}).get(line_no) or [])
    else:
        issue_rows = lint_line(src)
    err = info.get("error") if info else None

    expanded = src.expandtabs(4).rstrip()
    shown = expanded if len(expanded) <= 110 else expanded[:109] + "…"
    indent = len(expanded) - len(expanded.lstrip())
    layer = indent // 4

    out = []
    out.append("<div style='color:%s;font-size:11px;'>第 %d 行"
               " <span style='color:%s;font-weight:600;'>%s</span></div>"
               % (_DIM, line_no, _ACCENT, _esc(kind or "语句")))
    out.append("<div style=\"font-family:Consolas,'Courier New',monospace;color:%s;"
               "font-size:12px;background:#111823;padding:6px;border-radius:5px;"
               "margin:6px 0;\">%s</div>" % (_TEXT, _esc(shown)))
    if desc:
        out.append("<div style='color:%s;font-size:12px;'>%s</div>"
                   % (_TEXT, _esc(desc)))
    if err and int(err.get("line") or 0) == line_no:
        out.append("<div style='color:%s;font-size:12px;margin-top:6px;'>"
                   "语法错误：%s</div>"
                   % (_ERR, _esc(err.get("message") or "")))
    for level, msg in issue_rows[:5]:
        out.append("<div style='color:%s;font-size:11px;margin-top:4px;'>· %s</div>"
                   % (_WARN if level == "warn" else _ERR, _esc(msg)))
    out.append("<div style='color:%s;font-size:11px;margin-top:7px;'>"
               "缩进 %d 空格 · 层级 %d</div>" % (_DIM, indent, layer))
    return "".join(out)


# ---------------------------------------------------------------------------
# 悬停小面板
# ---------------------------------------------------------------------------
_TIP_W = 372
_TIP_PAD = 11


class _TipPanel(QFrame):
    """无边框小面板：圆角深色底 + 细边，跟随悬停行显示，不抢焦点、不挡鼠标。"""

    def __init__(self):
        super().__init__(None, Qt.WindowType.ToolTip |
                         Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(_TIP_PAD, _TIP_PAD, _TIP_PAD, _TIP_PAD)
        self._label = QLabel(self)
        self._label.setTextFormat(Qt.TextFormat.RichText)
        self._label.setWordWrap(True)
        self._label.setAlignment(Qt.AlignmentFlag.AlignLeft |
                                 Qt.AlignmentFlag.AlignTop)
        self._label.setStyleSheet("background: transparent; border: none;")
        lay.addWidget(self._label)

    def paintEvent(self, _e):      # noqa: N802  Qt 命名
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        path = QPainterPath()
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path.addRoundedRect(rect, 10, 10)
        p.fillPath(path, QColor(_SURFACE))
        p.strokePath(path, QColor(_BORDER))

    def show_tip(self, html: str, pos: QPoint):
        width = _TIP_W - 2 * _TIP_PAD
        self._label.setFixedWidth(width)
        self._label.setText(html)
        height = max(1, int(self._label.heightForWidth(width)))
        self._label.setFixedHeight(height)
        self.setFixedSize(_TIP_W, height + 2 * _TIP_PAD)

        screen = QApplication.screenAt(pos) or QApplication.primaryScreen()
        area = screen.availableGeometry()
        x = min(max(pos.x(), area.left() + 8), area.right() - self.width() - 8)
        y = pos.y()
        if y + self.height() > area.bottom():
            y = pos.y() - self.height() - 28
        y = max(area.top() + 8, y)
        self.move(x, y)
        self.show()
        self.raise_()

    def hide_tip(self):
        self.hide()


# ---------------------------------------------------------------------------
# 行号栏
# ---------------------------------------------------------------------------
class _LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self):      # noqa: N802
        return QSize(self._editor.line_number_area_width(), 0)

    def paintEvent(self, event):      # noqa: N802
        self._editor.paint_line_numbers(event)


class CodeEditor(QPlainTextEdit):
    """带行号栏 + 悬停行信号的代码编辑器。"""

    hover_line_changed = pyqtSignal(int)
    hover_left = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._line_area = _LineNumberArea(self)
        self._line_area.setAttribute(
            Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        #: 1 起行号 → "error" / "warn"：行号栏左侧色条 + 行号着色（行内波浪线另画）
        self._diag_lines = {}
        #: 最近一次鼠标移动在视口内的坐标（稳定停留校验用，避免用全局光标）
        self.last_hover_pos = QPoint(-1, -1)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        font = QFont("Consolas")
        font.setStyleHint(QFont.StyleHint.Monospace)
        font.setFixedPitch(True)
        font.setPointSizeF(10.5)
        self.setFont(font)
        self.setTabStopDistance(QFontMetricsF(font).horizontalAdvance(" ") * 4)

        self.blockCountChanged.connect(self._update_area_width)
        self.updateRequest.connect(self._on_update_request)
        self._update_area_width()

        self.setStyleSheet(
            "QPlainTextEdit { background: %s; color: %s; border: 1px solid %s;"
            " border-radius: 8px; padding: 6px 8px;"
            " selection-background-color: #1C3766; selection-color: #EAF0F6; }"
            "QPlainTextEdit:focus { border-color: #33455E; }"
            % (_EDIT_BG, _TEXT, _BORDER))

    # ---------- 诊断标记 ----------
    def set_diagnostics(self, levels: dict):
        """更新行号栏上的诊断标记（levels: 1 起行号 → error/warn）。"""
        self._diag_lines = dict(levels or {})
        self._line_area.update()

    # ---------- 行号栏 ----------
    def line_number_area_width(self) -> int:
        digits = max(3, len(str(max(1, self.blockCount())))
                     + (1 if self._big_mode() else 0))
        return 14 + digits * 8

    def _big_mode(self) -> bool:
        return self.blockCount() >= 1000

    def _update_area_width(self, *_args):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _on_update_request(self, rect: QRect, dy: int):
        if dy:
            self._line_area.scroll(0, dy)
        else:
            self._line_area.update(0, rect.y(),
                                   self._line_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_area_width()

    def resizeEvent(self, event):      # noqa: N802
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_area.setGeometry(QRect(cr.left(), cr.top(),
                                          self.line_number_area_width(),
                                          cr.height()))

    def paint_line_numbers(self, event):
        p = QPainter(self._line_area)
        p.fillRect(event.rect(), QColor(_EDIT_BG))
        block = self.firstVisibleBlock()
        number = block.blockNumber()
        top = int(self.blockBoundingGeometry(block)
                  .translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        current = self.textCursor().blockNumber()
        p.setFont(self.font())
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                level = self._diag_lines.get(number + 1)
                if level == "error":
                    num_color = _ERR
                elif level == "warn":
                    num_color = _WARN
                elif number == current:
                    num_color = _ACCENT
                else:
                    num_color = _DIM
                p.setPen(QColor(num_color))
                p.drawText(0, top, self._line_area.width() - 6,
                           self.fontMetrics().height(),
                           Qt.AlignmentFlag.AlignRight, str(number + 1))
                if level:
                    # 左侧 3px 色条：错误红、提示琥珀，扫一眼就能找到问题行
                    bar_h = max(1, int(bottom - top) - 4)
                    p.fillRect(QRect(2, top + 2, 3, bar_h),
                               QColor(_ERR if level == "error" else _WARN))
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            number += 1
        p.end()

    # ---------- 鼠标悬停 ----------
    def mouseMoveEvent(self, event):      # noqa: N802
        super().mouseMoveEvent(event)
        self.last_hover_pos = event.pos()
        block = self.cursorForPosition(event.pos()).blockNumber() + 1
        self.hover_line_changed.emit(block)

    def leaveEvent(self, event):      # noqa: N802
        super().leaveEvent(event)
        self.hover_left.emit()

    def wheelEvent(self, event):      # noqa: N802
        super().wheelEvent(event)
        self.hover_left.emit()


# ---------------------------------------------------------------------------
# 页面
# ---------------------------------------------------------------------------
def _mk_button(text: str, slot) -> QPushButton:
    btn = QPushButton(text)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setMinimumHeight(28)
    btn.setStyleSheet(
        "QPushButton { background: %s; color: %s; border: 1px solid %s;"
        " border-radius: 6px; padding: 0 12px; font-size: 12px; }"
        "QPushButton:hover { background: #16202E; border-color: #33455E; }"
        "QPushButton:pressed { background: #101822; }"
        % (_SURFACE, _TEXT, _BORDER))
    btn.clicked.connect(lambda _c=False: slot())
    return btn


class PyLintPage(QWidget):
    """Python 校准页（Copilot 浮层页签）。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("pyLintPage")
        self.setStyleSheet("#pyLintPage { background: %s; }" % _BG)

        self._analysis = None
        self._analysis_version = -1
        self._text_version = 0
        self._pending_line = -1
        self._diag_truncated = False
        self._tip = _TipPanel()

        self._hover_timer = QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(_HOVER_DELAY_MS)
        self._hover_timer.timeout.connect(self._show_pending_tip)

        self._check_timer = QTimer(self)
        self._check_timer.setSingleShot(True)
        self._check_timer.setInterval(320)
        self._check_timer.timeout.connect(self._recheck)

        self._build()

    # ---------- 构建 ----------
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(8)
        title = QLabel("Python 校准")
        f = QFont(title.font())
        f.setBold(True)
        f.setPointSizeF(max(11, f.pointSizeF() + 2))
        title.setFont(f)
        title.setStyleSheet("color: %s;" % _TEXT)
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(_mk_button("粘贴剪贴板", self._paste_clipboard))
        head.addWidget(_mk_button("打开文件", self._open_file))
        head.addWidget(_mk_button("清空", self._clear))
        root.addLayout(head)

        sub = QLabel("红色波浪线 = 语法错误，琥珀色波浪线 = 写法提示；行号栏色条标出问题行。"
                     "鼠标停在代码行上可弹出该行详解。所有分析都在本机完成，不会运行代码。")
        sub.setWordWrap(True)
        sub.setStyleSheet("color: %s; font-size: 11px;" % _DIM)
        root.addWidget(sub)

        self.editor = CodeEditor()
        self.highlighter = PythonHighlighter(self.editor.document())
        self.editor.setPlaceholderText(
            "在这里粘贴或输入 Python 代码。输入停顿后自动检查语法；"
            "鼠标移到某一行可查看该行提示。")
        root.addWidget(self.editor, 1)

        foot = QHBoxLayout()
        foot.setSpacing(8)
        self.status = QLabel("等待输入代码。")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color: %s; font-size: 11px;" % _DIM)
        foot.addWidget(self.status, 1)
        self.cursor_info = QLabel("行 1 · 列 1")
        self.cursor_info.setStyleSheet("color: %s; font-size: 11px;" % _DIM)
        foot.addWidget(self.cursor_info)
        root.addLayout(foot)

        self.editor.textChanged.connect(self._on_text_changed)
        self.editor.hover_line_changed.connect(self._on_hover_line)
        self.editor.hover_left.connect(self._hide_tip)
        self.editor.cursorPositionChanged.connect(self._on_cursor)
        self.editor.verticalScrollBar().valueChanged.connect(self._hide_tip)

    # ---------- 编辑与检查 ----------
    def _on_text_changed(self):
        self._text_version += 1
        self._pending_line = -1
        self._hide_tip()
        self._check_timer.start()

    def _on_cursor(self):
        cur = self.editor.textCursor()
        self.cursor_info.setText("行 %d · 列 %d"
                                 % (cur.blockNumber() + 1,
                                    cur.positionInBlock() + 1))

    def _recheck(self):
        text = self.editor.toPlainText()
        if not text.strip():
            self._analysis = None
            self._analysis_version = self._text_version
            self.editor.setExtraSelections([])
            self.editor.set_diagnostics({})
            self.status.setText("等待输入代码。")
            self.status.setStyleSheet("color: %s; font-size: 11px;" % _DIM)
            return
        if len(text) > _MAX_CHECK_CHARS:
            self._analysis = None
            self._analysis_version = self._text_version
            self.editor.setExtraSelections([])
            self.editor.set_diagnostics({})
            self.status.setText(
                "当前内容较长，已暂停实时分析以保持编辑流畅；悬停仍可查看单行提示。")
            self.status.setStyleSheet("color: %s; font-size: 11px;" % _DIM)
            return

        self._analysis = analyze_code(text)
        self._analysis_version = self._text_version
        self._paint_diagnostics()
        self._update_status()

    #: 波浪线最多标注多少个提示行（防超长文件一次画几千条选中区拖慢绘制）
    _MAX_DIAG_LINES = 200

    def _paint_diagnostics(self):
        """把语法错误与写法提示直接画进编辑器（不依赖悬停）：
        整行浅色底 + 波浪下划线 + 行号栏左侧色条 + 行号着色。"""
        info = self._analysis or {}
        doc = self.editor.document()
        selections = []
        levels = {}

        err = info.get("error")
        err_line = 0
        if err and int(err.get("line") or 0) > 0:
            err_line = min(max(1, int(err["line"])), max(1, doc.blockCount()))
            levels[err_line] = "error"

        issues = {int(k): v for k, v in (info.get("issues") or {}).items()}
        warn_lines = [ln for ln in sorted(issues)
                      if 1 <= ln <= doc.blockCount() and ln != err_line]
        truncated = len(warn_lines) > self._MAX_DIAG_LINES
        warn_lines = warn_lines[:self._MAX_DIAG_LINES]
        for ln in warn_lines:
            levels.setdefault(ln, "warn")
        self.editor.set_diagnostics(levels)
        self._diag_truncated = truncated

        if err_line:
            col = max(0, int(err.get("col") or 0) - 1)
            self._add_diag(selections, doc.findBlockByNumber(err_line - 1),
                           QColor(201, 106, 94, 30), QColor(_ERR), col)
        for ln in warn_lines:
            self._add_diag(selections, doc.findBlockByNumber(ln - 1),
                           QColor(198, 161, 91, 20),
                           QColor(208, 167, 93, 230), None)
        self.editor.setExtraSelections(selections)

    @staticmethod
    def _add_diag(selections: list, block, bg: QColor,
                  underline: QColor, start_col=None):
        """给一个文本追加诊断绘制：整行底色 + 从 start_col 到行尾的波浪线。"""
        if not block.isValid():
            return
        fmt = QTextCharFormat()
        fmt.setBackground(bg)
        fmt.setProperty(QTextFormat.Property.FullWidthSelection, True)
        sel = QTextEdit.ExtraSelection()
        sel.cursor = QTextCursor(block)
        sel.format = fmt
        selections.append(sel)

        text = block.text()
        if start_col is None:
            col = len(text) - len(text.lstrip())
        else:
            col = int(start_col)
            if col >= len(text):       # 语法错误指向行尾/EOF：整行画波浪线
                col = len(text) - len(text.lstrip())
        col = max(0, min(col, len(text)))
        cur = QTextCursor(block)
        cur.setPosition(block.position() + col)
        cur.movePosition(QTextCursor.MoveOperation.EndOfBlock,
                        QTextCursor.MoveMode.KeepAnchor)
        if not cur.hasSelection():
            return
        fmt2 = QTextCharFormat()
        fmt2.setUnderlineColor(underline)
        fmt2.setUnderlineStyle(QTextCharFormat.UnderlineStyle.WaveUnderline)
        sel2 = QTextEdit.ExtraSelection()
        sel2.cursor = cur
        sel2.format = fmt2
        selections.append(sel2)

    def _update_status(self):
        info = self._analysis or {}
        err = info.get("error")
        text = self.editor.toPlainText()
        warns = sum(len(v) for v in (info.get("issues") or {}).values())
        if err:
            line = int(err.get("line") or 0)
            col = int(err.get("col") or 0)
            msg = str(err.get("message") or "")
            row = "语法错误 · 第 %d 行 第 %d 列：%s" % (line, col, msg)
            if warns:
                row += " · 另有 %d 条写法提示" % warns
            self.status.setText(row)
            self.status.setStyleSheet("color: %s; font-size: 11px;" % _ERR)
            return
        row = "语法通过 · %d 行" % len(text.splitlines())
        if warns:
            row += " · %d 条写法提示" % warns
            if self._diag_truncated:
                row += "（仅标注前 %d 行）" % self._MAX_DIAG_LINES
        self.status.setText(row)
        self.status.setStyleSheet("color: %s; font-size: 11px;"
                                  % (_WARN if warns else _OK))

    # ---------- 悬停提示 ----------
    def _on_hover_line(self, line: int):
        if QApplication.mouseButtons() & Qt.MouseButton.LeftButton:
            self._hide_tip()
            return
        doc = self.editor.document()
        if line < 1 or line > doc.blockCount():
            self._hide_tip()
            return
        if line == self._pending_line:
            if not self._tip.isVisible() and not self._hover_timer.isActive():
                self._hover_timer.start()
            return
        self._pending_line = line
        self._hover_timer.start()

    def _show_pending_tip(self):
        line = self._pending_line
        if line < 1:
            return
        # 稳定停留校验：计时器到点时鼠标必须仍在同一行。
        # 划过其他行时只重置计时、不隐藏已有面板，因此不会出现「一闪一闪」。
        pos = self.editor.last_hover_pos
        if pos is None or pos.x() < 0 or pos.y() < 0:
            return
        line_now = self.editor.cursorForPosition(pos).blockNumber() + 1
        if line_now != line:
            self._pending_line = line_now
            self._hover_timer.start()
            return
        block = self.editor.document().findBlockByNumber(line - 1)
        if not block.isValid():
            return
        src = block.text()
        info = (self._analysis
                if self._analysis_version == self._text_version else None)
        html = build_line_tip(line, src, info)
        if not html:
            self._hide_tip()
            return
        rect = self.editor.cursorRect(QTextCursor(block))
        pos = self.editor.viewport().mapToGlobal(rect.topLeft())
        self._tip.show_tip(html, QPoint(pos.x() + 34, pos.y() + 14))

    def _hide_tip(self):
        self._pending_line = -1
        if self._hover_timer.isActive():
            self._hover_timer.stop()
        self._tip.hide_tip()

    # ---------- 操作 ----------
    def _paste_clipboard(self):
        text = QApplication.clipboard().text()
        if not text or not text.strip():
            self.status.setText("剪贴板里没有可粘贴的文本。")
            self.status.setStyleSheet("color: %s; font-size: 11px;" % _WARN)
            return
        cursor = self.editor.textCursor()
        cursor.insertText(text)
        self.editor.setTextCursor(cursor)
        self.editor.setFocus()

    def _open_file(self):
        path, _filter = QFileDialog.getOpenFileName(
            self, "打开 Python 文件", "", "Python 文件 (*.py);;所有文件 (*)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError as e:
            self.status.setText("打开失败：%s" % e)
            self.status.setStyleSheet("color: %s; font-size: 11px;" % _ERR)
            return
        self.editor.setPlainText(text)
        self.editor.moveCursor(QTextCursor.MoveOperation.Start)
        self.editor.setFocus()

    def _clear(self):
        self.editor.clear()
        self.editor.setFocus()

    # ---------- 生命周期 ----------
    def hideEvent(self, event):      # noqa: N802
        super().hideEvent(event)
        self._hide_tip()
        if self._tip.isVisible():
            self._tip.hide_tip()

    def closeEvent(self, event):      # noqa: N802
        self._hide_tip()
        self._tip.close()
        super().closeEvent(event)
